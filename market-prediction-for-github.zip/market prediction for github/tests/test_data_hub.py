import pandas as pd
import src.data_hub as hubmod

def configure(tmp_path,monkeypatch):
    monkeypatch.setattr(hubmod,'PROJECT',tmp_path)
    monkeypatch.setattr(hubmod,'ROOT',tmp_path/'hub')
    monkeypatch.setattr(hubmod,'CACHE',tmp_path/'hub'/'last_good')

def test_adapter_fallback_and_hash(tmp_path,monkeypatch):
    configure(tmp_path,monkeypatch)
    h=hubmod.DataHub('2026-09-18');h.session='2026-09-18'
    def fail():raise RuntimeError('blocked')
    def backup():return pd.DataFrame({'date':['2026-09-18'],'value':[1]})
    d=h.fetch('demo',[('primary',fail),('backup',backup)],lambda x:x.date.max())
    assert d.iloc[0].value==1 and h.results[-1].source=='backup' and h.results[-1].sha256

def test_future_payload_is_rejected(tmp_path,monkeypatch):
    configure(tmp_path,monkeypatch)
    h=hubmod.DataHub('2026-09-18');h.session='2026-09-18'
    bad=lambda:pd.DataFrame({'date':['2026-09-19'],'value':[1]})
    d=h.fetch('demo',[('bad',bad)],lambda x:x.date.max())
    assert d is None and h.results[-1].status=='failed'
